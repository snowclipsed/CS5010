package org.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Zelda {

    Maze zelda = new Maze();

    Node current = new Node("H8", null);
    private List<Node> nodelist;
    HashMap<String, String> dialogues = new HashMap<>();

    int rupy = 0;
    Zelda(){

        String gridAlphabets[] = new String[]{"A", "B", "C", "D", "E", "F", "G", "H"};


        for(int i = 0; i <= 7 ; i++){
            for(int j = 1; j <=16 ; j++){
                zelda.addNode(gridAlphabets[i] + j, null);
            }
        }

        for (int i = 0; i <=7; i++) {
            for (int j = 1; j <= 15; j++) {
                zelda.createEdge(gridAlphabets[i] + j, gridAlphabets[i] + (j + 1), null, null);
            }
        }

        for (int i = 1; i <=15; i++){
            for(int j = 0; j<7; j++){
                zelda.createEdge(gridAlphabets[j] + i, gridAlphabets[j+1] + (i), null, null);
            }
        }

        dialogues.put("G8", "Entered dungeon D0, Test");
        dialogues.put("D8", "Entered dungeon D1, the Eagle.");
        dialogues.put("D14", "Entered dungeon D2, the Moon" );
        dialogues.put("H5", "Entered dungeon D3, Manji" );
        dialogues.put("E6", "Entered dungeon D4, the Snake" );
        dialogues.put("A12", "Entered dungeon D5, the Lizard" );



        System.out.println(zelda.getAdjacencyList().get(new Node("H8", null)));

        System.out.println("\n \n\n \n\n \nNodes initialized, The Legend of Zelda is starting.");


        while(rupy<25){
            movePlayer();
        }



    }


    void printPrompt(String coords){
        if(dialogues.containsKey(coords)){
            System.out.println(dialogues.get(coords));
        }
    }

    void movePlayer(){
        nodelist = zelda.getAdjVertices(current.coords);
        boolean found = false;


        System.out.println("You may move to the following areas:");
        for(Node element : nodelist){
            System.out.println(element.coords);
        }
        System.out.println("\n");
        Scanner scanner = new Scanner(System.in);
        String response = scanner.nextLine();

        for(Node element : nodelist){
            if (response.equalsIgnoreCase(element.coords)) {
                found = true;
                current = element;
                System.out.println("\n Moved to " + current.coords);
                printPrompt(element.coords);
                if (dialogues.containsKey(element.coords)){
                    rupy += 5;
                }
                break;
            }
        }

        if(!found){
            System.out.println("Cannot move here. Try Again");
            movePlayer();
        }

    }

}
