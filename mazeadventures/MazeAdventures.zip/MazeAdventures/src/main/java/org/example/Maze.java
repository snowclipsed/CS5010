package org.example;

import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Maze {
    private Map<Node, List<Node>> adjacencyList;
    public Map<Node, List<Node>> getAdjacencyList() {
        return adjacencyList;
    }

    public void setAdjacencyList(Map<Node, List<Node>> adjacencyList) {
        this.adjacencyList = adjacencyList;
    }

    public Maze(){
        this.adjacencyList = new HashMap<>();
    }

    public void addNode(String coords, String prompt){
        adjacencyList.put(new Node(coords, prompt), new ArrayList<>());
        System.out.println("Created node " + coords);
    }

    public void removeNode(String coords, String prompt){
        Node node = new Node(coords, prompt);
        adjacencyList.values().stream().forEach(e->e.remove(node));
        adjacencyList.remove(new Node(coords, null));
    }

    public void createEdge(String coords1, String coords2, String prompt1, String prompt2){
        Node node1 = new Node(coords1, prompt1);
        Node node2 = new Node(coords2, prompt2);

        if (adjacencyList.containsKey(node1) && adjacencyList.containsKey(node2)){
            adjacencyList.get(node1).add(node2);
            adjacencyList.get(node2).add(node1);
            System.out.println("Connected " + coords1 + " and " + coords2);
        }
        else{
            System.out.println("Could not connect " + coords1 + " and " + coords2);
        }
    }

    public void removeEdge(String coords1, String coords2, String prompt1, String prompt2){
        Node node1 = new Node(coords1, prompt1);
        Node node2 = new Node(coords2, prompt2);

        List<Node> eN1 = adjacencyList.get(node1);
        List<Node> eN2 = adjacencyList.get(node2);

        if(eN1 != null){
            eN1.remove(node2);
        }
        if(eN2 != null){
            eN2.remove(node1);
        }

    }

    public List<Node> getAdjVertices(String label) {

        Node target = new Node(null, null);
        for(Node key : adjacencyList.keySet()){
            if(key.coords.equalsIgnoreCase(label)){
                target = key;
                break;
            }
        }

        return adjacencyList.get(target);

    }


}