package org.example;

import java.util.Objects;

public class Node {

    Boolean isDungeon = false;

    String coords;
    private String Prompt;
    public void setPrompt(String prompt) {
        this.Prompt = prompt;
    }

    Node(String coords, String Prompt){
        this.coords = coords;
        this.Prompt = Prompt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Node node = (Node) o;
        return Objects.equals(isDungeon, node.isDungeon) && Objects.equals(coords, node.coords) && Objects.equals(Prompt, node.Prompt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isDungeon, coords, Prompt);
    }




    public void printPrompt(){
        System.out.println(this.Prompt);
    }

    public void becomesDungeon(){
        this.isDungeon = true;
    }

}
