package org.example;

public class StartGame {
    public static void main(String[] args){
        Zelda game = new Zelda();
    }
}
