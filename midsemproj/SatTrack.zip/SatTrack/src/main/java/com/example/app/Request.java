package com.example.app;

import java.util.List;

public class Request {
    public Info info;

    public List<Positions> positions;
}
