package com.example.app;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.*;

class AppTest {


    @org.junit.jupiter.api.Test
    void returnNORADID() {
        // Create an instance of the class that contains the returnNORADID method
        App methodContainer = new App();

        // Test cases for each satellite option
        assertEquals(Integer.valueOf(25544), methodContainer.returnNORADID("ISS"));
        assertEquals(Integer.valueOf(43931), methodContainer.returnNORADID("IRIDIUM 167"));
        assertEquals(Integer.valueOf(58130), methodContainer.returnNORADID("STARLINK-30783"));
        assertEquals(Integer.valueOf(20580), methodContainer.returnNORADID("Hubble Space Telescope"));

        // Test the default case with an invalid satellite option
        assertEquals(Integer.valueOf(25544), methodContainer.returnNORADID("InvalidSatelliteOption"));
    }

    @org.junit.jupiter.api.Test
    void satAPICall() {
        Satellite mockSatellite = Mockito.mock(Satellite.class);

        // Set up the expected coordinates for the mock Satellite object
        Mockito.when(mockSatellite.satlong).thenReturn(123.45f);
        Mockito.when(mockSatellite.satlat).thenReturn(67.89f);

        // Use the mock Satellite object when the method is called
        Mockito.when(apiService.satAPICall(Mockito.anyInt())).thenReturn(new Float[]{mockSatellite.satlong, mockSatellite.satlat});

        // Call the method with a sample ID
        Float[] result = apiService.satAPICall(123);

        // Verify that the method returns the expected coordinates
        assertArrayEquals(new Float[]{123.45f, 67.89f}, result);

    }

    @org.junit.jupiter.api.Test
    void main() {
        // too small for any unit test
    }

    @org.junit.jupiter.api.Test
    void start() {
        // is the actual main function
    }

}