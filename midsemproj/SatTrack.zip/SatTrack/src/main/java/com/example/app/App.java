/**
 *
 *
 * NOTE : IF THIS FAILS TO RUN PLEASE CONTACT ME.
 *
 * IF APPTest SHOWS AN ERROR, DELETE THE JUNIT TEST, IT HAS ISSUES WITH GRADLE!
 *
 * ---
 *
 * BEFORE STARTING:
 *
 * Go to {@link com.example.app.Constants} and put in your API KEYS!!
 *
 *
 * --
 * Welcome to the main or App class.
 * This class uses an ARCGiS runtime communicating with a local JavaFX Scene to display a map of the Earth.
 * ARCGiS can also display feature layers and graphics on top of the map using JavaFX and built in support for graphics
 * in its API.
 *
 * Read more about ARCGiS here : @see <a href = "https://developers.arcgis.com/java/"> ARCGiS Documentation </a>
 * Read more on JavaFX here: @see <a href = "https://openjfx.io/">OpenJFX</a>
 *
 * You may notice that the imports are divided into various blocks. It's because this makes it easier to identify
 * libraries when you are debugging.
 *
 * Each block of the libraries serves its own purpose. The first block is Graphics related ARCGiS Libraries,
 * like Point and Graphic.
 *
 * The second block is used to render the map.
 *
 * The third block is JavaFX.
 *
 */



package com.example.app;
// Graphics Block
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.symbology.PictureMarkerSymbol;
import com.esri.arcgisruntime.symbology.TextSymbol;

//Maps Block
import com.esri.arcgisruntime.ArcGISRuntimeEnvironment;
import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.BasemapStyle;
import com.esri.arcgisruntime.mapping.Viewpoint;
import com.esri.arcgisruntime.mapping.view.MapView;

//JavaFX block
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.Slider;
import java.io.IOException;
import java.net.URISyntaxException;

/**
 * MapView :
 * A user interface control that displays two-dimensional (2D) geographic content defined by an ArcGISMap.
 * A MapView is a user interface that displays ArcGISMap layers and graphics in 2D. It controls the area (extent) of the ArcGISMap that is visible and supports user interactions such as pan and zoom. A map view also provides access to the underlying layer data in a map.
 *
 * {@link App#satID} : It is a global variable storing the NORAD ID of a website and can be changed using {@link App#returnNORADID(String)}.
 * It is input into {@link App#satAPICall(Integer)} which calls the N2YO Api @see <a href = "https://www.n2yo.com/api/"> N2YO API </a> to get the location
 * and relative position of the satellite from the observer.
 *
 * {@link  App#scale}: It is a global variable storing the zoom scale of the map. Its value is controlled by a slider.
 *
 */
public class App extends Application {

    private MapView mapView;
    private Integer satID = 25544;
    private  Double scale = 700000000.0;

    public static void main(String[] args) {
        Application.launch(args);
    }

    /**
     *
     * Starts the Application execution.
     *
     * @param stage the primary stage for this application, onto which
     * the application scene can be set.
     * Applications may create other stages, if needed, but they will not be
     * primary stages.
     * @throws URISyntaxException
     * @throws IOException
     * @throws InterruptedException
     *
     */

    @Override
    public void start(Stage stage) throws URISyntaxException, IOException, InterruptedException {

        // A string array of satellites we want to show.
        
        String[] satList =
                {
                        "ISS",
                        "Hubble Space Telescope",
                        "IRIDIUM 167",
                        "STARLINK-30783"
                };


        //Create a combo box to switch satellites

        ComboBox<String> combo_box =
                new ComboBox<>(FXCollections
                        .observableArrayList(satList));
        combo_box.setValue("ISS"); // Default Value set to ISS to not crash the system when it boots.


        // Add a slider to control zoom
        Slider slider = new Slider(0, 70000000, 70000000);
        slider.setShowTickMarks(true);
        slider.setShowTickLabels(true);
        slider.setMajorTickUnit(10000000f); // Set how much is a big tick.
        slider.setBlockIncrement(10000f);
        slider.setMaxSize(200,10);
        slider.setSnapToPixel(false);
        slider.setLayoutX(250);
        slider.setLayoutX(100);


        // Add the title to the window
        stage.setTitle("Satellite Tracker");
        stage.setWidth(700);
        stage.setHeight(700);
        stage.show();

        /**
         * Stackpane is a Stack implementation of the pane. It follows LIFO order, the layers instatiated last will appear on
         * the top.
         */
        StackPane stackPane = new StackPane();
        Scene scene = new Scene(stackPane);
        stage.setScene(scene);

        // Calling API key. Do not put your API key here for safety purposes.
        String yourApiKey = Constants.ARCAPI;
        ArcGISRuntimeEnvironment.setApiKey(yourApiKey);

        // Create a map view to display the map and add it to the stack pane
        mapView = new MapView();
        stackPane.getChildren().add(mapView);
        stackPane.getChildren().add(combo_box);
        stackPane.getChildren().add(slider);
        StackPane.setAlignment(slider, Pos.CENTER_LEFT);
        StackPane.setAlignment(combo_box, Pos.TOP_LEFT);

        // Make a map object and set its style
        ArcGISMap map = new ArcGISMap(BasemapStyle.ARCGIS_NOVA);

        // set the map on the map view
        mapView.setMap(map);
        Float[] coords = satAPICall(satID);
        mapView.setViewpoint(new Viewpoint(coords[1], coords[0], scale));

        // create a graphics overlay and add it to the map view
        GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
        graphicsOverlay.setLabelsEnabled(true);

        // create a point geometry with a location and spatial reference for the image.
        Point point = new Point(coords[0], coords[1], SpatialReferences.getWgs84());
        // create a point geometry for the text below the image.
        Point textpoint = new Point(coords[0], coords[1]-3, SpatialReferences.getWgs84());

        // display image at the point.
        PictureMarkerSymbol satmarker = new PictureMarkerSymbol("src/Images/satimage.png");
        satmarker.setHeight(40);
        satmarker.setWidth(40);

        //add text under the point.
        TextSymbol sattext = new TextSymbol(20, "ISS", Color.SNOW, TextSymbol.HorizontalAlignment.CENTER,
                TextSymbol.VerticalAlignment.TOP);
        // add outline to the text so it is more visible.
        sattext.setHaloWidth(1);
        sattext.setHaloColor(Color.BLACK);

        // make ARCGiS graphics out of the symbols for text and image point

        Graphic sattextgraphic = new Graphic(textpoint, sattext);

        Graphic satpoint = new Graphic(point, satmarker);

        // make a thread which calls the API every 10 seconds and then sets the point to the location of the moving satellite again.
        Thread updateThread = new Thread(() -> {
            while (true) {

                try {
                    setpoint(satpoint,sattextgraphic,mapView);
                } catch (URISyntaxException | IOException | InterruptedException e) {
                    throw new RuntimeException(e);
                }
//
                try {
                    Thread.sleep(10000); // Update every 10000 milliseconds (10 seconds). Change this to change update time.
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        updateThread.start();

        // Add a dropdown listener to select the satellite
        combo_box.setOnAction((event) -> {
            String selection = combo_box.getValue();
            satID = returnNORADID(selection);
            System.out.println(selection);
            System.out.println(satID);

            try {
                setpoint(satpoint, sattextgraphic,mapView);
            } catch (URISyntaxException | IOException | InterruptedException e) {
                throw new RuntimeException(e);
            }
            sattext.setText(selection);

        });

        // add listener for slider
        slider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                scale = (Double) newValue;
                mapView.setViewpointScaleAsync(scale);
            }
        });

        // add the point graphic to the graphics overlay
        graphicsOverlay.getGraphics().add(satpoint);
        graphicsOverlay.getGraphics().add(sattextgraphic);
        mapView.getGraphicsOverlays().add(graphicsOverlay);
    }


    /**
     *
     * @param point -> point location Graphic object
     * @param text -> text Graphic object
     * @param mapView ->ARCGiS MapView Object
     * @throws URISyntaxException
     * @throws IOException
     * @throws InterruptedException
     */
    public void setpoint(Graphic point, Graphic text, MapView mapView) throws URISyntaxException, IOException, InterruptedException {
        Float[] newcoords;
        newcoords = satAPICall(satID);
        Point newpoint = new Point(newcoords[0], newcoords[1], SpatialReferences.getWgs84());
        Point newimagepoint = new Point(newcoords[0], newcoords[1]-3, SpatialReferences.getWgs84());
        point.setGeometry(newpoint);
        text.setGeometry(newimagepoint);
        mapView.setViewpoint(new Viewpoint(newcoords[1], newcoords[0], scale));
    }

    /**
     * Switch statement to select NORAD ID based on satellite name in dropdown
     *
     * @param satOption Satellite name in dropdown. Corresponds to switch statement.
     * @return ID, returns the right ID according to switch statement.
     */
    public Integer returnNORADID(String satOption){
       int ID;
            switch (satOption){
                case "ISS":
                    ID = 25544;
                    break;
                case "IRIDIUM 167":
                    ID = 43931;
                    break;
                case "STARLINK-30783":
                    ID = 58130;
                    break;
                case"Hubble Space Telescope":
                    ID = 20580;
                    break;
                default:
                    ID = 25544;
            }
        return ID;
    }

    /**
     * Makes an API call according to the NORAD ID provided by calling the {@link Satellite} class object.
     *
     * @param ID NORAD ID of Satellite object
     * @return {@link Satellite#satlat} {@link Satellite#satlong} satellite coords.
     * @throws URISyntaxException
     * @throws IOException
     * @throws InterruptedException
     */
    public Float[] satAPICall(Integer ID) throws URISyntaxException, IOException, InterruptedException {
        Satellite satellite = new Satellite(ID.toString(), "1", "-70.24637829392033", "43.66167125666995", Constants.N2YOAPI);
        return new Float[]{satellite.satlong,satellite.satlat};
    }


}

