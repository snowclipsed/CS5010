package com.example.app;

public class Constants {
// Enter API Keys HERE
    public static String ARCAPI = "";

    public static String N2YOAPI = "";


}
