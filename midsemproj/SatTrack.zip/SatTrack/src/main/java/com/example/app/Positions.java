package com.example.app;

public class Positions {

    public Float satlatitude;
    public Float satlongitude;
    public Float sataltitude;
    public Float azimuth;
    public Float elevation;
    public Float ra;
    public Float dec;
    public Float timestamp;
    public Boolean eclipsed;

}
