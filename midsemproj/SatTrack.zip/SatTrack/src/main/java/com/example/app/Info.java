package com.example.app;

public class Info {

    public String satname;
    public String satid;
    public String transactionscount;

    public String getSatname() {
        return satname;
    }

    public void setSatname(String satname) {
        this.satname = satname;
    }


    public String getSatid() {
        return satid;
    }

    public void setSatid(String satid) {
        this.satid = satid;
    }

    public String getTransactionscount() {
        return transactionscount;
    }

    public void setTransactionscount(String transactionscount) {
        this.transactionscount = transactionscount;
    }
}
